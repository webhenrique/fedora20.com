                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2806149
FDM Friendly "Steins;gate" Upa by thnikk is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I found myself using spope's Upa as a benchmark print, but it required a lot of modification to actually get it to print in one part. Even as multiple parts, it's still not designed to be printed by an FDM printer.

I decided to start from scratch and make my own model, and this is what I came up with. It's not perfect, and I learned a lot in the process about modeling features onto a sphere. There re a few goals I was going for when designing the model:

- Make no ugly unprintable curves (meaning have the bottom of spheres not have an unprintable overhang without support). The underside of the ears have a 30 degree overhang (which wasn't a problem for me even with the not-so-great part cooling fan on the Printrbot Play) and the underside of the body has a 45 degree overhang, so that should print perfectly for anyone. 

- Don't have a bunch of intersecting shells that make it impossible to print in one piece. This is a freebie with fusion.

- Do some stress-testing.

- Make it as close to the original with my current skills.

There are 3 models included. One is normal, one has the 45 degree bottom, and one has the 45 degree bottom and tail support. 

# Print Settings

Printer Brand: Printrbot
Printer: Play
Rafts: No
Supports: Yes
Resolution: 0.1mm
Infill: 0-30%

Notes: 
- Try printing with a lower extrusion width if you're not using a .3mm nozzle. It will still give you some finer detail and make the grooves more defined, since that''s all of the detail of the model. If you do this, you should also increase the width of the first layer to compensate so it prints normally.

- Print it hollow! If it doesn't need to be strong, I think it prints even better without infill and it'll save a lot of plastic and print time. If you do this, concentric infill works really well, especially if you're printing in a clear plastic.

- Print at as fine of a resolution as you can to reduce the vertical stair-stepping.