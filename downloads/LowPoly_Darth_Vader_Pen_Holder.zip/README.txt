                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2449436
LowPoly Darth Vader Pen Holder by jhwblender is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

If you want a pen holder with style, this is the perfect one for any Star Wars fan. This'll make a great gift or personal desk item. Permit Lord Vader to give you your pen/ring/remote/phone etc and hold it for as long as you deem necessary. 

This is a remix of the "Low-Poly Darth Vader" from FLOWALISTIK. 
It was pretty difficult to modify the standing Vader model. I used Blender and had to separate the arms from the body and position him just right. Then I modified the original cape and did cloth simulation to get it to drape correctly. 



# Print Settings

Printer: Anet A8
Rafts: No
Supports: Yes
Resolution: 0.1mm
Infill: 100%

Notes: 
These are the print settings that I used, but feel free to experiment. 
I highly highly recommend using a brim. There are small parts at the bottom that can break off early on.